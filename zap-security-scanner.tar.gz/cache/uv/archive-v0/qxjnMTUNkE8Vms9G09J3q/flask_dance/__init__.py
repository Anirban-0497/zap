"Doing the OAuth dance with style using Flask, requests, and oauthlib"
from .consumer import OAuth1ConsumerBlueprint, OAuth2ConsumerBlueprint

__version__ = "7.1.0"
